import 'dotenv/config';
import express from 'express';
import bodyParser from 'body-parser';
import axios from 'axios';
import crypto from 'crypto';
import path from 'path';
import { fileURLToPath } from 'url';
import sqlite3 from 'sqlite3';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// For normal JSON routes
app.use(bodyParser.json());
// Static demo UI
app.use(express.static(path.join(__dirname, 'public')));

const db = new sqlite3.Database(path.join(__dirname, 'store.sqlite'));

// --- DB setup (products, orders, order_items) ---
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    price REAL NOT NULL,
    image TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    status TEXT DEFAULT 'pending',
    provider TEXT,
    total_amount REAL DEFAULT 0,
    currency TEXT DEFAULT 'USD',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    payment_url TEXT,
    provider_order_id TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    product_name TEXT,
    unit_price REAL NOT NULL,
    variation TEXT,
    coordinates TEXT,
    image_url TEXT,
    quantity INTEGER DEFAULT 1,
    FOREIGN KEY(order_id) REFERENCES orders(id)
  )`);

  // Seed demo products if table empty
  db.get('SELECT COUNT(*) as c FROM products', (err, row) => {
    if (!row || row.c === 0) {
      const stmt = db.prepare('INSERT INTO products (name, description, price, image) VALUES (?,?,?,?)');
      [
        ['Blackout Hoodie', 'Черно худи, киберпънк визия', 49.90, 'https://picsum.photos/seed/hoodie/400/300'],
        ['Neon Cap', 'Snapback шапка с неонов шев', 24.50, 'https://picsum.photos/seed/cap/400/300'],
        ['Cyber Tee', 'Тениска с glitch принт', 29.00, 'https://picsum.photos/seed/tee/400/300'],
      ].forEach(p => stmt.run(...p));
      stmt.finalize();
      console.log('✅ Seeded sample products');
    }
  });
});

function calcTotal(items) {
  return items.reduce((sum, it) => sum + (Number(it.unit_price) * Number(it.quantity || 1)), 0);
}

// List products
app.get('/api/products', (req, res) => {
  db.all('SELECT * FROM products', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// Create order + create WolvPay invoice (hosted by default)
app.post('/api/orders', async (req, res) => {
  try {
    const { items = [], currency = 'USD', coin = null, description = null, white_label = false } = req.body;
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'items required' });
    }

    const total = calcTotal(items);
    const orderId = await new Promise((resolve, reject) => {
      db.run('INSERT INTO orders (status, provider, total_amount, currency) VALUES (?,?,?,?)',
        ['pending', 'wolvpay', total, currency],
        function(err) { if (err) reject(err); else resolve(this.lastID); });
    });

    const insertItem = db.prepare(`INSERT INTO order_items
      (order_id, product_id, product_name, unit_price, variation, coordinates, image_url, quantity)
      VALUES (?,?,?,?,?,?,?,?)`);
    items.forEach(it => {
      insertItem.run(orderId, it.product_id, it.product_name || '', it.unit_price, it.variation || '', it.coordinates || '', it.image_url || '', it.quantity || 1);
    });
    insertItem.finalize();

    const apiKey = process.env.WOLVPAY_API_KEY;
    const base = process.env.WOLVPAY_API_BASE || 'https://wolvpay.com/api/v1';
    const redirectUrl = `${process.env.PUBLIC_BASE_URL}/order/${orderId}/thank-you`;

    const payload = {
      amount: Number(total.toFixed(2)),
      currency,
      description: description || `Order #${orderId}`,
      redirect_url: redirectUrl,
      white_label: Boolean(white_label)
    };
    if (coin) payload.coin = coin; // optional coin selection

    let paymentUrl = null;
    let providerOrderId = null;
    try {
      const { data } = await axios.post(`${base}/invoices`, payload, {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        }
      });
      if (data?.data) {
        paymentUrl = data.data.url || null;           // hosted
        providerOrderId = data.data.invoice_id || null;
      }
    } catch (e) {
      console.error('WolvPay create invoice error:', e.response?.data || e.message);
    }

    await new Promise((resolve, reject) => {
      db.run('UPDATE orders SET payment_url = ?, provider_order_id = ? WHERE id = ?',
        [paymentUrl, providerOrderId, orderId],
        function(err){ if (err) reject(err); else resolve(); });
    });

    res.json({ order_id: orderId, total, currency, payment_url: paymentUrl, invoice_id: providerOrderId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'order_create_failed' });
  }
});

// WolvPay webhook requires raw body for signature verification
const rawJson = bodyParser.raw({ type: 'application/json' });
app.post('/webhook/wolvpay', rawJson, (req, res) => {
  try {
    const signature = req.headers['x-wolvpay-signature'];
    const secret = process.env.WOLVPAY_WEBHOOK_SECRET || '';
    const computed = crypto.createHmac('sha256', secret).update(req.body).digest('hex');

    if (!signature || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(computed))) {
      console.warn('Invalid WolvPay signature');
      return res.status(401).send('invalid signature');
    }

    const event = JSON.parse(req.body.toString('utf8'));
    // Expect typical fields: { invoice_id, status, ... }
    const invId = event?.data?.invoice_id || event?.invoice_id;
    const status = (event?.data?.status || event?.status || '').toUpperCase();

    // Map statuses per docs
    let mapped = 'pending';
    if (status === 'PAID' || status === 'COMPLETED' || status === 'CONFIRMED') mapped = 'paid';
    if (status === 'EXPIRED' || status === 'CANCELLED') mapped = 'cancelled';

    if (invId) {
      db.run('UPDATE orders SET status = ? WHERE provider_order_id = ?', [mapped, invId], function(err){
        if (err) console.error('Webhook DB update error:', err.message);
      });
    }

    res.sendStatus(200);
  } catch (e) {
    console.error('WolvPay webhook error:', e.message);
    res.sendStatus(200);
  }
});

// Minimal test UI
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/order/:id/thank-you', (req, res) => res.sendFile(path.join(__dirname, 'public', 'thankyou.html')));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`✅ WolvPay backend running on http://localhost:${PORT}`));
