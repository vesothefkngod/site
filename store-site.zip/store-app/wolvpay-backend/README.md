# WolvPay Shop Backend (Express + SQLite)

Лек бекенд за магазин с поръчки и уникални редове (вариации, координати, снимка) + интеграция с **WolvPay** (хостван checkout по подразбиране).

Документация, на която е базирано: https://wolvpay.com/docs  (Invoices API, Webhooks).

## Стартиране локално
```bash
npm install
# редактирай .env с:
# - WOLVPAY_API_KEY=...
# - WOLVPAY_WEBHOOK_SECRET=... (за подписа)
npm start
# отваряш
http://localhost:3001
```

## Основни ендпойнти
- `GET /api/products` — листинг на продукти
- `POST /api/orders` — създава поръчка и вика WolvPay Create Invoice (POST /invoices)
  - тяло: `{ items: [...], currency, coin?, description?, white_label? }`
  - връща: `{ order_id, total, currency, payment_url, invoice_id }`
- `POST /webhook/wolvpay` — приема WolvPay webhook (HMAC-SHA256 подпис в `X-WolvPay-Signature`)

## Бележки
- По подразбиране правим **Hosted invoice** (white_label=false), за да получим `data.url` и да редиректнем клиента.
- Ако подадеш `white_label=true` и/или `coin`, ще получиш адрес/сума за директен адресен чек-аут (без `url`). Тогава ти трябва собствен UI за инструкциите.
- `PUBLIC_BASE_URL` трябва да е публичният ти домейн за коректен redirect.
